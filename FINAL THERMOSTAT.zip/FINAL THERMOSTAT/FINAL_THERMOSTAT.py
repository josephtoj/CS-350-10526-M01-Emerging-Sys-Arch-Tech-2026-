﻿#!/usr/bin/env python3
"""
CS 350 Final Project – Smart Thermostat

- Default set point: 72°F
- Modes: OFF → HEAT → COOL
- AHT20 via I2C
- Red LED = Heat
- Blue LED = Cool
- LCD: Date/Time + alternating Temp / Mode+Setpoint
- UART: comma-delimited output every 30 seconds
"""

import time
from datetime import datetime
import logging
from gpiozero import Button, PWMLED
import serial
import qwiic_aht20
from Display16x2 import Display16x2


# ---------------- GPIO PINS ----------------
RED_LED_PIN = 18
BLUE_LED_PIN = 23

MODE_BUTTON_PIN = 24
UP_BUTTON_PIN = 25
DOWN_BUTTON_PIN = 12

DEFAULT_SETPOINT = 72
MIN_SETPOINT = 50
MAX_SETPOINT = 90
SETPOINT_STEP = 1

UART_PORT = "/dev/serial0"
UART_BAUD = 9600


# ---------------- GLOBAL STATE ----------------
mode = "off"
set_point = DEFAULT_SETPOINT
current_temp = 72.0

# Use monotonic clocks for intervals to avoid issues when system clock changes
last_uart_time = 0.0
last_toggle_time = time.monotonic()
show_temp_line = True

# Hardware handles (may be None if init fails)
sensor = None
lcd = None
red_led = None
blue_led = None
mode_button = None
up_button = None
down_button = None
serial_port = None


# ---------------- LOGGING ----------------
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


# ---------------- HARDWARE INIT ----------------
def init_hardware():
    global sensor, lcd, red_led, blue_led
    global mode_button, up_button, down_button, serial_port

    # Sensor
    try:
        s = qwiic_aht20.QwiicAHT20()
        if s.isConnected():
            try:
                s.getSensorReading()
                sensor = s
                logging.info("AHT20 sensor initialized.")
            except Exception:
                logging.exception("AHT20 present but initial read failed; sensor disabled.")
        else:
            logging.warning("AHT20 sensor not connected; continuing without sensor.")
    except Exception:
        logging.exception("Failed to initialize AHT20 sensor; continuing without sensor.")

    # LCD
    try:
        lcd = Display16x2()
        logging.info("LCD initialized.")
    except Exception:
        logging.exception("Failed to initialize LCD; continuing without LCD.")
        lcd = None

    # LEDs
    try:
        red_led = PWMLED(RED_LED_PIN)
        blue_led = PWMLED(BLUE_LED_PIN)
        logging.info("LEDs initialized.")
    except Exception:
        logging.exception("Failed to initialize LEDs; continuing without them.")
        red_led = None
        blue_led = None

    # Buttons (add simple debounce to reduce bounce-triggered multiples)
    try:
        mode_button = Button(MODE_BUTTON_PIN, pull_up=True, bounce_time=0.12)
        up_button = Button(UP_BUTTON_PIN, pull_up=True, bounce_time=0.12)
        down_button = Button(DOWN_BUTTON_PIN, pull_up=True, bounce_time=0.12)
        logging.info("Buttons initialized.")
    except Exception:
        logging.exception("Failed to initialize buttons; continuing without them.")
        mode_button = None
        up_button = None
        down_button = None

    # Serial / UART
    try:
        serial_port = serial.Serial(UART_PORT, UART_BAUD, timeout=1)
        logging.info("UART opened on %s @ %d", UART_PORT, UART_BAUD)
    except Exception:
        logging.exception("Failed to open UART; UART output disabled.")
        serial_port = None


# ---------------- FUNCTIONS ----------------
def safe_get_sensor_temperature():
    """Return temperature in Fahrenheit or None if unavailable."""
    if not sensor:
        return None
    try:
        if sensor.isConnected() and sensor.getSensorReading():
            temp_c = sensor.temperature
            return (temp_c * 9.0 / 5.0) + 32.0
    except Exception:
        logging.exception("Error reading temperature from sensor.")
    return None


def read_temperature():
    global current_temp
    temp = safe_get_sensor_temperature()
    if temp is not None:
        current_temp = temp
    else:
        logging.debug("Using cached temperature value: %.2f", current_temp)


def stop_led_effects():
    """Stop any active LED pulse/blink effects safely."""
    try:
        if red_led:
            if hasattr(red_led, "stop"):
                red_led.stop()
            else:
                red_led.source = None
            red_led.off()
    except Exception:
        logging.exception("Error stopping red LED.")
    try:
        if blue_led:
            if hasattr(blue_led, "stop"):
                blue_led.stop()
            else:
                blue_led.source = None
            blue_led.off()
    except Exception:
        logging.exception("Error stopping blue LED.")


def update_leds():
    if not (red_led and blue_led):
        return

    # ensure previous animations are stopped before starting new ones
    stop_led_effects()

    try:
        m = mode.lower()
        if m == "off":
            red_led.off()
            blue_led.off()
        elif m == "heat":
            if current_temp < set_point:
                red_led.pulse(fade_in_time=1, fade_out_time=1, n=None, background=True)
                blue_led.off()
            else:
                red_led.on()
                blue_led.off()
        elif m == "cool":
            if current_temp > set_point:
                blue_led.pulse(fade_in_time=1, fade_out_time=1, n=None, background=True)
                red_led.off()
            else:
                blue_led.on()
                red_led.off()
    except Exception:
        logging.exception("Error updating LED states.")


def update_lcd():
    global show_temp_line, last_toggle_time
    if not lcd:
        return

    try:
        now = time.monotonic()
        # First line: date/time (use wall clock for human-friendly value)
        lcd.display_string(datetime.now().strftime("%m/%d %H:%M:%S"), 1)

        if now - last_toggle_time > 2:
            show_temp_line = not show_temp_line
            last_toggle_time = now

        if show_temp_line:
            lcd.display_string(f"Temp:{current_temp:.1f}F".ljust(16), 2)
        else:
            lcd.display_string(f"{mode.upper()} SP:{set_point}F".ljust(16), 2)
    except Exception:
        logging.exception("Error updating LCD.")


def disable_uart():
    global serial_port
    try:
        if serial_port:
            serial_port.close()
    except Exception:
        logging.exception("Error closing UART.")
    serial_port = None


def send_uart():
    global last_uart_time
    now = time.monotonic()
    if now - last_uart_time > 30:
        message = f"{mode},{current_temp:.2f},{set_point}\n"
        if serial_port:
            try:
                serial_port.write(message.encode())
                serial_port.flush()
            except Exception:
                logging.exception("UART write failed; disabling UART.")
                disable_uart()
        else:
            logging.debug("UART disabled; would send: %s", message.strip())
        last_uart_time = now


# ---------------- BUTTON CALLBACKS ----------------
def change_mode():
    global mode
    try:
        if mode == "off":
            mode = "heat"
        elif mode == "heat":
            mode = "cool"
        else:
            mode = "off"
        logging.info("Mode changed to: %s", mode)
    except Exception:
        logging.exception("Error changing mode.")


def increase_temp():
    global set_point
    try:
        new_val = set_point + SETPOINT_STEP
        if new_val > MAX_SETPOINT:
            logging.debug("Setpoint already at maximum: %d", set_point)
            set_point = MAX_SETPOINT
        else:
            set_point = new_val
        logging.info("Setpoint increased to: %d", set_point)
    except Exception:
        logging.exception("Error increasing setpoint.")


def decrease_temp():
    global set_point
    try:
        new_val = set_point - SETPOINT_STEP
        if new_val < MIN_SETPOINT:
            logging.debug("Setpoint already at minimum: %d", set_point)
            set_point = MIN_SETPOINT
        else:
            set_point = new_val
        logging.info("Setpoint decreased to: %d", set_point)
    except Exception:
        logging.exception("Error decreasing setpoint.")


def bind_button_callbacks():
    try:
        if mode_button:
            mode_button.when_pressed = change_mode
        if up_button:
            up_button.when_pressed = increase_temp
        if down_button:
            down_button.when_pressed = decrease_temp
    except Exception:
        logging.exception("Failed to bind button callbacks.")


# ---------------- CLEANUP / MAIN ----------------
def cleanup():
    logging.info("Cleaning up hardware resources.")
    try:
        stop_led_effects()
    except Exception:
        logging.exception("Error cleaning LEDs.")
    try:
        if lcd:
            lcd.clear()
    except Exception:
        logging.exception("Error clearing LCD.")
    try:
        if serial_port:
            serial_port.close()
    except Exception:
        logging.exception("Error closing serial port.")


def main():
    init_hardware()
    bind_button_callbacks()

    # allow LCD to be cleared at start
    if lcd:
        try:
            lcd.clear()
        except Exception:
            logging.exception("Error clearing LCD at startup.")

    logging.info("Thermostat started (mode=%s, set_point=%d)", mode, set_point)

    try:
        while True:
            read_temperature()
            update_leds()
            update_lcd()
            send_uart()
            time.sleep(0.1)
    except KeyboardInterrupt:
        logging.info("Interrupted by user.")
    except Exception:
        logging.exception("Unhandled exception in main loop.")
    finally:
        cleanup()


if __name__ == "__main__":
    main()
